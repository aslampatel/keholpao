import React, { memo, useState,useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity,ScrollView } from 'react-native';
import Background from '../components/Background';
import Logo from '../components/Logo';
import Header from '../components/Header';
import Button from '../components/Button';
import TextInput from '../components/TextInput';
import BackButton from '../components/BackButton';
import { theme } from '../core/theme';
import { Navigation } from '../types';
import { StoreData,GetStoreDate } from '../../store/Store';
import { useToast } from 'react-native-paper-toast';
import { StackActions } from '@react-navigation/native';
import { DataTable } from 'react-native-paper';
import { useFocusEffect } from '@react-navigation/native';
import { Base_URL,PostDataWithToken ,GetDataWithToken} from '../../Apis/ApiHelper';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  emailValidator,
  passwordValidator,
  nameValidator,
} from '../core/utils';


const ProfileScreen = ({ navigation },props) => {
  const [first_name, setFName] = useState({ value: '', error: '' });
  const [last_name, setLName] = useState({ value: '', error: '' });
  const [mobile_number, setMobileNumber] = useState({ value: '', error: '' });
  const [email, setEmail] = useState({ value: '', error: '' });
  const [password, setPassword] = useState({ value: '', error: '' });
  const [device_toekn, setDeviceToekn] = useState("");
  const [UserProfile, setUserProfile] = useState([]);
  const [WalletAmount, setWalletAmount] = useState(0);
  const [TokenValue, setToken] = useState({ tokens: '', langs: '' });
  const toaster = useToast();
  //

 useFocusEffect(
    React.useCallback(() => {

          (async function() {
                
            let Tokendata={
              tokens: await AsyncStorage.getItem('Token'),
              langs:'en'
            }
            // console.log(Tokendata.tokens);
            setToken(Tokendata);
            GetDashboard(Tokendata);
          })();
      
    }, [])
  );
  const logout = () =>{

     navigation.navigate('Logout');
  }
  const Changepassword = () =>{

     navigation.navigate('ChangepasswordScreen');
  }

   function GetDashboard(Tokendata){
    //
    let Endpoints = 'user/user-profile';
    // console.log("endpoints:"+Endpoints);
    GetDataWithToken(Endpoints,Tokendata,'').then((response) =>{
        console.log('token type='+JSON.stringify(response));
       response = JSON.parse(JSON.stringify(response));
       // response = JSON.parse(response.data);
        // console.log('response='+response);
       if(response.data){
         setUserProfile(response.data.profile)
         setWalletAmount(response.data.wallet_amount)
         
          // console.log('response='+JSON.stringify(response.data.course));

       }
       
   });

  }

  return (
    <ScrollView>
    <Background>
      

      <Logo />
      <View style={{ flexDirection: 'row'}}>
         <DataTable>
          <DataTable.Header>
            <DataTable.Title>Name</DataTable.Title>
            <DataTable.Title>{UserProfile.first_name+' '+UserProfile.last_name}</DataTable.Title>
          </DataTable.Header>
      </DataTable>
      </View>

      
       <View style={{ flexDirection: 'row'}}>
         <DataTable>
          <DataTable.Header>
            <DataTable.Title>Mobile Number</DataTable.Title>
            <DataTable.Title>{UserProfile.mobile_number}</DataTable.Title>
          </DataTable.Header>
      </DataTable>
      </View>

      

      <View style={{ flexDirection: 'row'}}>
         <DataTable>
          <DataTable.Header>
            <DataTable.Title>Amount</DataTable.Title>
            <DataTable.Title>Rs.{WalletAmount}</DataTable.Title>
          </DataTable.Header>
      </DataTable>

      </View>
      <Button mode="contained" onPress={Changepassword}>
       Change Password
      </Button>
      <Button mode="contained" onPress={logout}>
       Logout
      </Button>
    </Background>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  label: {
    color: theme.colors.secondary,
  },
  button: {
    marginTop: 24,
  },
  row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
  contain_row:{
    padding:2,
    flex:1,
    width:"90%"

  }
});

export default memo(ProfileScreen);
